<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tatkal Doctor - WhatsApp Appointment Booking System</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="{{ asset('front') }}/assets/styles.css" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('uploads') }}/logo/tatkaldoctor-favicon.png">
  </head>

  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo">
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav align-items-center">
            <li class="nav-item"><a class="nav-link" href="#home">HOME</a></li>
            <li class="nav-item">
              <a class="nav-link" href="#products">PRODUCTS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#features">FEATURES</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#support">SUPPORT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('contact') }}">CONTACT US</a>
            </li>
            <li class="nav-item">
              <a class="nav-link demo" href="#demo">DEMO</a>
            </li>
            <a href="{{ route('login') }}"><button class="btn-login">LOGIN</button></a>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
      <div class="container">
        <h1>WhatsApp Appointment Booking System</h1>

        <div class="phone-carousel">
          <button
            class="carousel-arrow left"
            data-bs-target="#heroCarousel"
            data-bs-slide="prev"
          >
            ‹
          </button>

          <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <!-- Slide 1 -->
              <div class="carousel-item active">
                <div class="carousel-container">
                  <div class="phone-mockup">
                    <div class="phone-screen">
                      <div class="phone-notch"></div>
                      <div class="step-content">
                        <!-- RESPONSIVE IMAGE -->
                        <picture>
                          <!-- Mobile Image -->
                          <source
                            srcset="{{ asset('uploads') }}/slider/slide1.png"
                            media="(max-width: 768px)"
                          />
                          <!-- Desktop Image -->
                          <img
                            src="{{ asset('uploads') }}/slider/herobg.png"
                            alt="Step 1"
                            class="img-fluid"
                          />
                        </picture>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Slide 2 -->
              <div class="carousel-item">
                <div class="carousel-container">
                  <div class="phone-mockup">
                    <div class="phone-screen">
                      <div class="phone-notch"></div>
                      <div class="step-content">
                        <picture>
                          <source
                            srcset="{{ asset('uploads') }}/slider/slide2.png"
                            media="(max-width: 768px)"
                          />
                          <img
                            src="{{ asset('uploads') }}/slider/herobg.png"
                            alt="Step 2"
                            class="img-fluid"
                          />
                        </picture>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Slide 3 -->
              <div class="carousel-item">
                <div class="carousel-container">
                  <div class="phone-mockup">
                    <div class="phone-screen">
                      <div class="phone-notch"></div>
                      <div class="step-content">
                        <picture>
                          <source
                            srcset="{{ asset('uploads') }}/slider/slide3.png"
                            media="(max-width: 768px)"
                          />
                          <img
                            src="{{ asset('uploads') }}/slider/herobg.png"
                            alt="Step 3"
                            class="img-fluid"
                          />
                        </picture>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Slide 4 -->
              <div class="carousel-item">
                <div class="carousel-container">
                  <div class="phone-mockup">
                    <div class="phone-screen">
                      <div class="phone-notch"></div>
                      <div class="step-content">
                        <picture>
                          <source
                            srcset="{{ asset('uploads') }}/slider/slide4.png"
                            media="(max-width: 768px)"
                          />
                          <img
                            src="{{ asset('uploads') }}/slider/herobg.png"
                            alt="Step 4"
                            class="img-fluid"
                          />
                        </picture>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <button
            class="carousel-arrow right"
            data-bs-target="#heroCarousel"
            data-bs-slide="next"
          >
            ›
          </button>
        </div>

        <div class="carousel-indicators">
          <button
            type="button"
            data-bs-target="#heroCarousel"
            data-bs-slide-to="0"
            class="indicator active"
          ></button>
          <button
            type="button"
            data-bs-target="#heroCarousel"
            data-bs-slide-to="1"
            class="indicator"
          ></button>
          <button
            type="button"
            data-bs-target="#heroCarousel"
            data-bs-slide-to="2"
            class="indicator"
          ></button>
          <button
            type="button"
            data-bs-target="#heroCarousel"
            data-bs-slide-to="3"
            class="indicator"
          ></button>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-7">
            <h2 class="text-green">TRANSFORM YOUR CLINIC WITH WHATSAPP AUTOMATION</h2>
            <h3>Smart appointment booking & patient communication via WhatsApp</h3>
            <ul class="feature-list">
              <li>Automatically respond to patient inquiries using WhatsApp</li>
              <li>Patient registration and appointment scheduling through WhatsApp</li>
              <li>Automated appointment confirmations, updates, and rescheduling on WhatsApp</li>
              <li>Secure delivery of test results and medical updates via WhatsApp</li>
              <li>Automated appointment reminders via WhatsApp messages and voice calls</li>
              <li>Enhanced patient satisfaction & long-term loyalty</li>
            </ul>
            <button class="btn-start">START FOR FREE!</button>
          </div>
          <div class="col-lg-5">
            <div class="phone-mockup-large">
              <img
                src="{{ asset('uploads') }}/home_page/1.png"
                alt="WhatsApp Interface"
                class="img-fluid"
              />
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Service Icons Section -->
    <section class="services-icons">
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <div
              class="service-card d-flex justify-content-center align-items-center"
            >
              <div class="service-icon">
                <img src="{{ asset('uploads') }}/home_page/icon-1.png" alt="" />
              </div>
              <div class="ps-3">
                <h4>List of Services</h4>
                <p>Easily configure clinic services, doctors, and appointment flows through an intelligent WhatsApp chatbot</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div
              class="service-card d-flex justify-content-center align-items-center"
            >
              <div class="service-icon">
                <img src="{{ asset('uploads') }}/home_page/icon-2.png" alt="" />
              </div>
              <div class="ps-3">
                <h4>Send Reminders</h4>
                <p>Automatically send appointment confirmations, reminders, and updates via WhatsApp and voice calls</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div
              class="service-card d-flex justify-content-center align-items-center"
            >
              <div class="service-icon">
                <img src="{{ asset('uploads') }}/home_page/icon-3.png" alt="" />
              </div>
              <div class="ps-3">
                <h4>Patient Support</h4>
                <p>Provide round-the-clock patient support through an automated WhatsApp chatbot—no human intervention required</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Appointment Reminders Section -->
    <section class="reminders-section">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <h2>Appointment Reminders & Post-Treatment Care via WhatsApp</h2>
            <div class="reminder-item">
              <h4><span class="reminder-icon">✓</span>Scheduling</h4>
              <p>
                Patients can easily book, reschedule, or cancel appointments directly through WhatsApp—no apps or phone calls required.
              </p>
            </div>
            <div class="reminder-item">
              <h4>
                <span class="reminder-icon">✓</span>Real-time WhatsApp Notifications
              </h4>
              <p>
                Real-time WhatsApp notifications and reminders reduce no-shows and keep patients informed at every step.
              </p>
            </div>
            <div class="reminder-item">
              <h4><span class="reminder-icon">✓</span>Improved Efficiency</h4>
              <p>
                Clinics and hospitals operate more efficiently by automating appointment management, saving valuable time and staff effort.
              </p>
            </div>
            <div class="reminder-item">
              <h4><span class="reminder-icon">✓</span>Cost Savings</h4>
              <p>
                Reduced administrative workload and paper-based processes result in significant cost savings for clinics and hospitals.
              </p>
            </div>
          </div>
          <div class="col-lg-6">
            <img
              src="{{ asset('uploads') }}/home_page/2.png"
              alt="Doctor and Patient"
              class="doctor-image"
            />
          </div>
        </div>
      </div>
    </section>

    <!-- Statistics Section -->
    <section class="stats-section">
      <div class="container">
        <h2>MEDICAL CLINIC SCHEDULES 2.5X</h2>
        <p class="subtitle">MORE APPOINTMENTS WITH WHATSAPP</p>
        <div class="row">
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">+60%</div>
              <div class="stat-label">Scheduling<br />Efficiency</div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">-30%</div>
              <div class="stat-label">No-show<br />Rates</div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">2.5x</div>
              <div class="stat-label">Qualified<br />Appointments</div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">+25%</div>
              <div class="stat-label">Patient<br />Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section service-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="image">
              <img src="{{ asset('uploads') }}/home_page/bgnew.png" class="img-fluid rounded-4" alt="" />
            </div>
          </div>
          <div class="col-md-6">
            <div
              class="content d-flex flex-column justify-content-center h-100 text-center"
            >
              <h2>Faster and More Efficient communication</h2>
              <p>
                Tatkal Doctor transforms the way clinics and patients communicate by replacing slow phone calls with instant WhatsApp and voice-based interactions. Patients can easily book appointments, check availability, reschedule visits, or ask basic questions without waiting in queues. Doctors and clinic staff receive real-time appointment updates directly on WhatsApp, ensuring no information is missed. This fast and efficient communication reduces response time, eliminates confusion, and keeps everyone informed at every step..
              </p>
            </div>
          </div>
        </div>
        <div class="row mt-5 pt-5">
          <div class="col-md-6">
            <div
              class="content d-flex flex-column justify-content-center h-100 text-center"
            >
              <h2>Automated Notifications</h2>
              <p>
                With Tatkal Doctor, appointment communication runs automatically. Patients receive instant booking confirmations, timely reminders, and follow-up messages via WhatsApp and voice calls. These automated notifications significantly reduce no-shows and last-minute cancellations. Clinics no longer need to manually call or message patients—saving time while maintaining consistent and reliable communication throughout the appointment lifecycle.
              </p>
            </div>
          </div>
          <div class="col-md-6">
            <div class="image">
              <img src="{{ asset('uploads') }}/home_page/3.png" class="img-fluid rounded-4" alt="" />
            </div>
          </div>
        </div>
        <div class="row mt-5 pt-5">
          <div class="col-md-6">
            <div class="image">
              <img src="{{ asset('uploads') }}/home_page/4.png" class="img-fluid rounded-4" alt="" />
            </div>
          </div>
          <div class="col-md-6">
            <div
              class="content d-flex flex-column justify-content-center h-100 text-center"
            >
              <h2>Personalized Messaging</h2>
              <p>
                Every message sent through Tatkal Doctor is tailored to the individual patient. Notifications include the patient’s name, doctor’s name, appointment date and time, clinic address, and relevant instructions. This personalized approach makes interactions feel more human and professional, building trust and improving patient engagement. Even though the system is automated, patients experience communication that feels personal and caring.
              </p>
            </div>
          </div>
        </div>
        <div class="row mt-5 pt-5">
          <div class="col-md-6">
            <div
              class="content d-flex flex-column justify-content-center h-100 text-center"
            >
              <h2>Enhanced Patient Experience</h2>
              <p>
                Tatkal Doctor is designed with patients in mind. By using WhatsApp—a platform patients already trust—the booking process becomes simple and stress-free for all age groups. Patients enjoy quick responses, easy rescheduling options, and clear appointment reminders without needing to install any app or visit complex websites. This smooth and convenient experience leads to higher satisfaction, better engagement, and stronger long-term relationships between patients and healthcare providers.
              </p>
            </div>
          </div>
          <div class="col-md-6">
            <div class="image">
              <img src="{{ asset('uploads') }}/home_page/5.png" class="img-fluid rounded-4" alt="" />
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="stats-new">
      <div class="container">
        <h2>MEDICAL CLINIC SCHEDULES 2.5X</h2>
        <p class="subtitle">MORE APPOINTMENTS WITH VOICE AI</p>
        <div class="row">
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">+60%</div>
              <div class="stat-label">Scheduling<br />Efficiency</div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">-30%</div>
              <div class="stat-label">No-show<br />Rates</div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">2.5x</div>
              <div class="stat-label">Qualified<br />Appointments</div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="stat-card">
              <div class="stat-number">+25%</div>
              <div class="stat-label">Patient<br />Satisfaction</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Voice AI Agents Section -->
    <section class="voice-ai-section">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <h2>
              <span class="blue-text">VOICE AI AGENTS FOR</span><br />HEALTHCARE
              CALL ROUTING
            </h2>
            <p class="lead">
              Answer every patient call, route it automatically, and reduce
              no-shows. TatkalDoctor's Voice AI Agents simplify transfers across
              100+ clinics and departments, so your team can scale care access
              without scaling headcount.
            </p>
            <p class="features-text">
              Inbound Appointment Booking | Lead Qualification | Handling FAQ
            </p>
          </div>
          <div class="col-lg-6">
            <img
              src="{{ asset('uploads') }}/home_page/6.png"
              alt="Voice AI Agent"
              class="img-fluid rounded-4"
            />
          </div>
        </div>
      </div>
    </section>

    <!-- Blogs Section -->
    <section class="blogs-section">
      <div class="container">
        <h2 class="text-center"><span class="blue-text">BLOGS</span></h2>
        <h3 class="text-center mb-5">
          IMPROVING MULTI-CLINIC MANAGEMENT WITH WHATSAPP AUTOMATION
        </h3>
        <div class="row g-4">
          <div class="col-md-4">
            <div class="blog-card">
              <div class="blog-image">
                <img
                  src="{{ asset('uploads') }}/home_page/7.png"
                  alt="WhatsApp Automation"
                  class="img-fluid"
                />
                <span class="blog-tag">WhatsApp AUTOMATION</span>
              </div>
              <div class="blog-content">
                <h4>
                  How Healthcare Software in New Delhi is Improving Multi-Clinic
                  Management with WhatsApp Automation
                </h4>
                <p class="blog-date">June 13, 2025</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="blog-card">
              <div class="blog-image">
                <img
                  src="{{ asset('uploads') }}/home_page/8.png"
                  alt="Digitize Pharmacy"
                  class="img-fluid"
                />
                <span class="blog-tag orange">Digitize Your PHARMACY</span>
              </div>
              <div class="blog-content">
                <h4>
                  How to Digitize Your Pharmacy in the India with Digital
                  Solutions
                </h4>
                <p class="blog-date">May 6, 2025</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="blog-card">
              <div class="blog-image">
                <img
                  src="{{ asset('uploads') }}/home_page/9.png"
                  alt="Patient Management"
                  class="img-fluid"
                />
                <span class="blog-tag red"
                  >Transforming Patient MANAGEMENT</span
                >
              </div>
              <div class="blog-content">
                <h4>
                  Medical Software in Bangalore: Transforming Patient Management
                </h4>
                <p class="blog-date">February 7, 2025</p>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="pagination-custom text-end mt-4">
                <button class="page-btn">1</button>
                <button class="page-btn active">2</button>
                <button class="page-btn">3</button>
                <button class="page-btn">...</button>
                <button class="page-btn">20</button>
                <button class="page-btn">Next »</button>
            </div> -->
      </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-5">
            <h2 class="blue-text">FAQ's</h2>
            <h3>
              Everything You Need to Know About Tatkal Doctor's AI Voice Agents
            </h3>
          </div>
          <div class="col-lg-7">
            <div class="accordion" id="faqAccordion">
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq1"
                  >
                    How does Tatkal Doctor route patients to the correct clinic or
                    department without phone menus?
                  </button>
                </h2>
                <div
                  id="faq1"
                  class="accordion-collapse collapse show"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    Our AI Voice Agent uses natural language processing to
                    understand patient needs and automatically routes calls to
                    the appropriate clinic or department without requiring
                    traditional phone menus.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq2"
                  >
                    What happens if a patient just says something like "I need
                    to reschedule" or "I have a question"?
                  </button>
                </h2>
                <div
                  id="faq2"
                  class="accordion-collapse collapse"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    The AI agent intelligently identifies the intent and asks
                    relevant follow-up questions to understand their needs and
                    provide appropriate assistance.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq3"
                  >
                    Can Tatkal Doctor route calls after hours, on weekends, or
                    during high volume?
                  </button>
                </h2>
                <div
                  id="faq3"
                  class="accordion-collapse collapse"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    Yes, our AI agents work 24/7 and can handle unlimited
                    concurrent calls, ensuring no patient call goes unanswered.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq4"
                  >
                    How long does setup take across a large clinic network?
                  </button>
                </h2>
                <div
                  id="faq4"
                  class="accordion-collapse collapse"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    Setup typically takes 1-2 weeks for large clinic networks,
                    including configuration, testing, and staff training.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq5"
                  >
                    Do we have to change our phone system?
                  </button>
                </h2>
                <div
                  id="faq5"
                  class="accordion-collapse collapse"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    No, our solution integrates seamlessly with your existing
                    phone system without requiring any hardware changes.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq6"
                  >
                    Can our team update call flows without writing code?
                  </button>
                </h2>
                <div
                  id="faq6"
                  class="accordion-collapse collapse"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    Yes, our intuitive dashboard allows your team to easily
                    update call flows, scripts, and routing rules without any
                    coding knowledge.
                  </div>
                </div>
              </div>
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#faq7"
                  >
                    Is Tatkal Doctor secure and healthcare compliant?
                  </button>
                </h2>
                <div
                  id="faq7"
                  class="accordion-collapse collapse"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body">
                    Yes, we are fully HIPAA compliant and use enterprise-grade
                    encryption to ensure all patient data remains secure and
                    confidential.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
      <div class="footer-main">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
              <h5 class="footer-title">Ready to Transform Your Business?</h5>
              <button class="btn-schedule">
                Schedule Now <i class="fas fa-arrow-right"></i>
              </button>
              <div class="footer-logo mt-4">
                <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo">
              </div>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
              <h5 class="footer-title">Company</h5>
              <ul class="footer-links">
                <li><a href="#">WhatsApp API Pricing</a></li>
                <li><a href="#">Whatsapp Business Solutions</a></li>
                <li><a href="#">Book a Demo</a></li>
                <li><a href="#">Contact us</a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
              <h5 class="footer-title">Other Locations</h5>
              <ul class="footer-links">
                <li><a href="#">New Delhi</a></li>
                <li><a href="#">Coimbatore</a></li>
                <li><a href="#">Hyderabad</a></li>
                <li><a href="#">Bangalore</a></li>
                <li><a href="#">Mumbai</a></li>
              </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
              <h5 class="footer-title">Industry</h5>
              <ul class="footer-links">
                <li><a href="#">Chatbot for Medical</a></li>
                <li><a href="#">Chatbot for Education</a></li>
                <li><a href="#">Chatbot for Automotive</a></li>
                <li><a href="#">Chatbot for Travel & Hospitality</a></li>
                <li><a href="#">Chatbot for Healthcare</a></li>
              </ul>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
              <h5 class="footer-title">Contact us</h5>
              <div class="contact-info">
                <p>
                  <i class="fas fa-map-marker-alt"></i>Address: 2ND Floor, Vinayak Complex,
                 Sakarpur, Computer Market,
                 Near Nirman Vihar Metro Station, Delhi-110092</p>
                <p><i class="fas fa-phone"></i> +91 - 9891681122</p>
                <p><i class="fas fa-envelope"></i> doctortatkal@gmail.com</p>
              </div>
              <div class="social-icons mt-3">
                <a href="https://www.facebook.com/profile.php?id=61585476892452 "target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.instagram.com/tatkaldoctor/" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://www.linkedin.com/company/tatkaldoctor/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://x.com/tatkaldoctor" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="#" target="_blank"><i class="fab fa-youtube"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-6">
              <p class="mb-0">
                Copyright © TatkalDoctor 2025, All rights reserved.
              </p>
            </div>
            <div class="col-md-6 text-md-end">
              <a href="{{ route('privacy') }}" class="footer-link">Privacy Policy</a> |
              <a href="{{ route('terms') }}" class="footer-link">Terms & Conditions</a>
            </div>
          </div>
          <div class="text-center mt-2">
            <small>Official Partners | Business Partners</small>
          </div>
        </div>
      </div>
      <a
        href="https://wa.me/919891681122"
        class="whatsapp-float"
        target="_blank"
      >
        <i class="fab fa-whatsapp"></i>
      </a>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- <script>
        const steps = [
            {
                title: "Step 1",
                desc: "Scan the Doctor / Clinic WhatsApp QRcode",
                content: "QR CODE"
            },
            {
                title: "Step 2",
                desc: 'Patients send "Hi" message and start Booking Process',
                content: "CHAT"
            },
            {
                title: "Step 3",
                desc: "Choose the Days and Time to Make An Appointment",
                content: "SELECT"
            },
            {
                title: "Step 4",
                desc: "After completing all the steps Patient & Doctor will get the Confirmation Message",
                content: "CONFIRM"
            }
        ];

        let currentSlide = 0;

        function renderCarousel() {
            const container = document.getElementById('carouselContainer');
            container.innerHTML = '';

            const phone = document.createElement('div');
            phone.className = 'phone-mockup';
            phone.innerHTML = `
                <div class="phone-screen">
                    <div class="phone-notch"></div>
                    <div class="step-content">
                        <div style="font-size: 3rem; margin: 20px 0;">${steps[currentSlide].content === 'QR CODE' ? '⬜' : steps[currentSlide].content === 'CHAT' ? '💬' : steps[currentSlide].content === 'SELECT' ? '📅' : '✅'}</div>
                        <div style="color: #666; font-size: 1.1rem;">${steps[currentSlide].content}</div>
                    </div>
                </div>
                <div class="step-label">
                    <div class="step-title">${steps[currentSlide].title}</div>
                    <div class="step-desc">${steps[currentSlide].desc}</div>
                </div>
            `;
            container.appendChild(phone);
        }

        function updateIndicators() {
            const indicators = document.querySelectorAll('.indicator');
            indicators.forEach((ind, idx) => {
                ind.classList.toggle('active', idx === currentSlide);
            });
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % steps.length;
            renderCarousel();
            updateIndicators();
        }

        function prevSlide() {
            currentSlide = (currentSlide - 1 + steps.length) % steps.length;
            renderCarousel();
            updateIndicators();
        }

        function goToSlide(index) {
            currentSlide = index;
            renderCarousel();
            updateIndicators();
        }

        // Auto-advance carousel
        setInterval(nextSlide, 4000);

        // Initialize
        renderCarousel();
    </script> -->
  </body>
</html>
