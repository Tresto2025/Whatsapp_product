<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Contact Us — Tatkal Doctor</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="{{ asset('front') }}/assets/styles.css" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('uploads') }}/logo/tatkaldoctor-favicon.png">
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container">
        <a class="navbar-brand" href="index.html"
          ><img src="{{ asset('uploads') }}/logo/logo.png" alt="logo"
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav align-items-center">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('home') }}">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#products">PRODUCTS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#features">FEATURES</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#support">SUPPORT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('contact') }}">CONTACT US</a>
            </li>
            <li class="nav-item">
              <a class="nav-link demo" href="#demo">DEMO</a>
            </li>
            <a href="{{ route('login') }}"><button class="btn-login">LOGIN</button></a>
          </ul>
        </div>
      </div>
    </nav>

    <section class="contact-section py-5 py-lg-6 bg-light">
      <div class="container">
        <div class="text-center mb-5">
          <h1 class="display-5 fw-bold text-success">
            Contact Us
          </h1>
          <p class="lead text-muted">
            Have a question or need support? Reach out to us — we’re here to help.
          </p>
        </div>

        <div class="row g-4">
          <div class="col-lg-6">
            <div
              class="contact-info-card p-4 p-md-5 rounded-4 shadow-lg h-100 bg-white border-0"
            >
              <h2 class="h3 mb-4 text-primary">
                Get in touch
              </h2>
              <p class="text-secondary mb-4">
                If you have queries about services, pricing, or technical support, contact us:
              </p>

              <div class="list-group list-group-flush mb-4">
                <div
                  class="list-group-item d-flex align-items-start p-3 border-0"
                >
                  <div class="icon-square me-3 flex-shrink-0">
                    <i class="fas fa-map-marker-alt fa-lg text-success"></i>
                  </div>
                  <div>
                    <h5 class="fw-bold mb-0">Office</h5>
                    <p class="mb-0 text-muted">
                      2ND Floor, Vinayak Complex,
                        Sakarpur, Computer Market,
                        Near Nirman Vihar Metro Station, Delhi-110092
                    </p>
                  </div>
                </div>

                <div
                  class="list-group-item d-flex align-items-start p-3 border-0"
                >
                  <div class="icon-square me-3 flex-shrink-0">
                    <i class="fas fa-phone-alt fa-lg text-success"></i>
                  </div>
                  <div>
                    <h5 class="fw-bold mb-0">Phone</h5>
                    <a
                      href="tel:+919891681122"
                      class="text-decoration-none text-dark d-block"
                      >+91 - 9891681122</a
                    >
                  </div>
                </div>

                <div
                  class="list-group-item d-flex align-items-start p-3 border-0"
                >
                  <div class="icon-square me-3 flex-shrink-0">
                    <i class="fas fa-envelope fa-lg text-success"></i>
                  </div>
                  <div>
                    <h5 class="fw-bold mb-0">Email</h5>
                    <a
                      href="mailto:doctortatkal@gmail.com"
                      class="text-decoration-none text-dark d-block"
                      >doctortatkal@gmail.com</a
                    >
                    <small class="text-muted"
                      >Support / Refunds:
                      <a
                        href="mailto:doctortatkal@gmail.com"
                        class="text-decoration-none text-muted"
                        >doctortatkal@gmail.com</a
                      >
                      |
                      <a
                        href="tel:+919891681188"
                        class="text-decoration-none text-muted"
                        >+91 9891681188</a
                      ></small
                    >
                  </div>
                </div>
              </div>

              <div class="mt-4 pt-3 border-top social-icons-modern">
                <a href="#" class="social-icon-link me-3"
                  ><i class="fab fa-facebook-f fa-lg"></i
                ></a>
                <a href="#" class="social-icon-link me-3"
                  ><i class="fab fa-instagram fa-lg"></i
                ></a>
                <a href="#" class="social-icon-link me-3"
                  ><i class="fab fa-linkedin-in fa-lg"></i
                ></a>
                <a href="#" class="social-icon-link me-3"
                  ><i class="fab fa-twitter fa-lg"></i
                ></a>
                <a href="#" class="social-icon-link"
                  ><i class="fab fa-youtube fa-lg"></i
                ></a>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div
              class="contact-form-card p-4 p-md-5 rounded-4 shadow-lg h-100 bg-white border-0"
            >
              <h2 class="h3 mb-4 text-primary">
                Send us a message
              </h2>

              <form id="contactFormModern" action="#" method="post">
                <div class="form-floating mb-3">
                  <input
                    type="text"
                    class="form-control"
                    id="name"
                    name="name"
                    placeholder="abc"
                    required
                  />
                  <label for="name">Name</label>
                </div>

                <div class="form-floating mb-3">
                  <input
                    type="email"
                    class="form-control"
                    id="email"
                    name="email"
                    placeholder="abc@mail.com"
                    required
                  />
                  <label for="email">Email</label>
                </div>

                <div class="form-floating mb-3">
                  <input
                    type="tel"
                    class="form-control"
                    id="phone"
                    name="phone"
                    placeholder="99999 99999"
                  />
                  <label for="phone">Phone</label>
                </div>

                <div class="form-floating mb-4">
                  <textarea
                    class="form-control"
                    id="message"
                    name="message"
                    placeholder="Message"
                    rows="5"
                    style="height: 150px"
                    required
                  ></textarea>
                  <label for="message">Message</label>
                </div>

                <button
                  type="submit"
                  class="btn btn-success btn-lg w-100 send-btn"
                >
                  Send Message
                  <span
                    class="spinner-border spinner-border-sm d-none ms-2"
                    role="status"
                    aria-hidden="true"
                  ></span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

    <script>
      document
        .getElementById("contactFormModern")
        ?.addEventListener("submit", function (e) {
          e.preventDefault();

          const form = this;
          const sendBtn = form.querySelector(".send-btn");
          const spinner = form.querySelector(".spinner-border");

          // Show spinner and disable button
          sendBtn.disabled = true;
          spinner.classList.remove("d-none");
          sendBtn.innerHTML =
            'Sending... <span class="spinner-border spinner-border-sm ms-2" role="status" aria-hidden="true"></span>';

          // Simulate a network request (replace with actual AJAX/Fetch call)
          setTimeout(() => {
            // Hide spinner and enable button
            spinner.classList.add("d-none");
            sendBtn.disabled = false;
            sendBtn.innerHTML = "Send Message";

            // Show success message (using Bootstrap Alert/Toast in a real scenario)
            alert(
              "Thank You So much!"
            );
            form.reset();
          }, 2000); // 2 second delay for simulation
        });
    </script>

  <!-- Start Footer -->
  <footer class="footer">
    <div class="footer-main">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Ready to Transform Your Business?</h5>
            <button class="btn-schedule">
              Schedule Now <i class="fas fa-arrow-right"></i>
            </button>
            <div class="footer-logo mt-4">
              <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo">
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Company</h5>
            <ul class="footer-links">
              <li><a href="#">WhatsApp API Pricing</a></li>
              <li><a href="#">Whatsapp Business Solutions</a></li>
              <li><a href="#">Book a Demo</a></li>
              <li><a href="#">Contact us</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Other Locations</h5>
            <ul class="footer-links">
              <li><a href="#">New Delhi</a></li>
              <li><a href="#">Coimbatore</a></li>
              <li><a href="#">Hyderabad</a></li>
              <li><a href="#">Bangalore</a></li>
              <li><a href="#">Mumbai</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Industry</h5>
            <ul class="footer-links">
              <li><a href="#">Chatbot for Medical</a></li>
              <li><a href="#">Chatbot for Education</a></li>
              <li><a href="#">Chatbot for Automotive</a></li>
              <li><a href="#">Chatbot for Travel & Hospitality</a></li>
              <li><a href="#">Chatbot for Healthcare</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Contact us</h5>
            <div class="contact-info">
              <p>
                <i class="fas fa-map-marker-alt"></i> Address: 2ND Floor, Vinayak Complex,
                    Sakarpur, Computer Market,
                 Near Nirman Vihar Metro Station, Delhi-110092
              </p>
              <p><i class="fas fa-phone"></i> +91 - 9891681122</p>
              <p><i class="fas fa-envelope"></i> doctortatkal@gmail.com</p>
            </div>
            <div class="social-icons mt-3">
              <a href="https://www.facebook.com/profile.php?id=61585476892452" target="_blank"><i class="fab fa-facebook-f"></i></a>
              <a href="https://www.instagram.com/tatkaldoctor/" target="_blank"><i class="fab fa-instagram"></i></a>
              <a href="https://www.linkedin.com/company/tatkaldoctor/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
              <a href="https://x.com/tatkaldoctor" target="_blank"><i class="fab fa-twitter"></i></a>
              <a href="#"target="_blank"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <p class="mb-0">
              Copyright © TatkalDoctor 2025, All rights reserved.
            </p>
          </div>
          <div class="col-md-6 text-md-end">
            <a href="{{ route('privacy') }}" class="footer-link">Privacy Policy</a> |
            <a href="{{ route('terms') }}" class="footer-link">T & C</a> |
            <a href="{{ route('refunds') }}" class="footer-link">Refunds</a> | 
             <a href="{{ route('shipping') }}" class="footer-link">Shipping & Delivery</a>
          </div>
        </div>
        <div class="text-center mt-2">
          <small>Official Partners | Business Partners</small>
        </div>
      </div>
    </div>
    <a href="https://wa.me/919891681122" class="whatsapp-float" target="_blank">
      <i class="fab fa-whatsapp"></i>
    </a>
  </footer>

  <!-- End Footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
