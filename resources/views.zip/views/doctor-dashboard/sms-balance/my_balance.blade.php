@extends('layouts.admin', ['activePage' => 'doctor-my-balance', 'titlePage' => __('My Balance')])

@section('content')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">

            <!-- Total SMS -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card aligner-wrapper">
                    <div class="card-body">
                        <div class="absolute left top bottom h-100 v-strock-2 bg-primary"></div>
                        <p class="mb-2 text-dark">Total Message Balance</p>
                        <div class="d-flex align-items-center">
                            <h1 class="font-weight-medium mb-2 text-dark">{{ $balance->total_sms ?? 0 }}</h1>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-primary dot-indicator"></div>
                            <p class="text-muted mb-0 ml-2">Overall purchased</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Pending SMS -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card aligner-wrapper">
                    <div class="card-body">
                        <div class="absolute left top bottom h-100 v-strock-2 bg-success"></div>
                        <p class="mb-2 text-dark">Remaining Messages</p>
                        <div class="d-flex align-items-center">
                            <h1 class="font-weight-medium mb-2 text-dark">{{ $balance->pending_sms ?? 0 }}</h1>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-success dot-indicator"></div>
                            <p class="text-muted mb-0 ml-2">Available balance</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Spent SMS -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card aligner-wrapper">
                    <div class="card-body">
                        <div class="absolute left top bottom h-100 v-strock-2 bg-danger"></div>
                        <p class="mb-2 text-dark">Spent Messages</p>
                        <div class="d-flex align-items-center">
                            <h1 class="font-weight-medium mb-2 text-dark">{{ $balance->spent_sms ?? 0 }}</h1>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-danger dot-indicator"></div>
                            <p class="text-muted mb-0 ml-2">Already used</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Today’s SMS Sent -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card aligner-wrapper">
                    <div class="card-body">
                        <div class="absolute left top bottom h-100 v-strock-2 bg-info"></div>
                        <p class="mb-2 text-dark">Today’s Usage</p>
                        <div class="d-flex align-items-center">
                            <h1 class="font-weight-medium mb-2 text-dark">{{ $todaySms ?? 0 }}</h1>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-info dot-indicator"></div>
                            <p class="text-muted mb-0 ml-2">SMS sent today</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- This Month SMS Sent -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card aligner-wrapper">
                    <div class="card-body">
                        <div class="absolute left top bottom h-100 v-strock-2 bg-warning"></div>
                        <p class="mb-2 text-dark">This Month’s Usage</p>
                        <div class="d-flex align-items-center">
                            <h1 class="font-weight-medium mb-2 text-dark">{{ $monthSms ?? 0 }}</h1>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-warning dot-indicator"></div>
                            <p class="text-muted mb-0 ml-2">SMS sent this month</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Last Recharge -->
            <div class="col-md-4 grid-margin stretch-card">
                <div class="card aligner-wrapper">
                    <div class="card-body">
                        <div class="absolute left top bottom h-100 v-strock-2 bg-secondary"></div>
                        <p class="mb-2 text-dark">Last Recharge</p>
                        <div class="d-flex align-items-center">
                            <h1 class="font-weight-medium mb-2 text-dark">
                                ₹{{ $lastRecharge->amount ?? 0 }}
                            </h1>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="bg-secondary dot-indicator"></div>
                            <p class="text-muted mb-0 ml-2">
                               {{ $lastRecharge?->created_at?->format('d-M-Y h:i A') ?? 'N/A' }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Quick Action -->
        <div class="row mt-3">
            <div class="col-md-12 text-center">
                <a href="{{ route('doctor.sms-balance') }}" class="btn btn-primary btn-lg">
                    <i class="mdi mdi-cart"></i> Buy More SMS
                </a>
            </div>
        </div>
    </div>

@endsection
