<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Cancellation &amp; Refund Policy — Tatkal Doctor</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="{{ asset('front') }}/assets/styles.css" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('uploads') }}/logo/tatkaldoctor-favicon.png">
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container">
        <a class="navbar-brand" href="{{ route('home') }}"
          ><img src="{{ asset('uploads') }}/logo/logo.png" alt="logo"
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav align-items-center">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('home') }}">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#products">PRODUCTS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#features">FEATURES</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#support">SUPPORT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('contact') }}">CONTACT US</a>
            </li>
            <li class="nav-item">
              <a class="nav-link demo" href="#demo">DEMO</a>
            </li>
            <li class="nav-item"><button class="btn-login">LOGIN</button></li>
          </ul>
        </div>
      </div>
    </nav>

    <section class="terms-wrapper">
      <div class="terms-container">
        <h2 class="terms-heading">Cancellation & Refund Policy</h2>
        <p class="updated-date"><i>Last updated: 06 November 2025</i></p>

        <div class="terms-content">
          <div class="term-box">
            <h4>1. Cancellation by Customer</h4>
            <p>
              If you cancel a paid service or booking, cancellation eligibility
              and refund amount depend on the product/service type and the time
              of cancellation.
            </p>
          </div>

          <div class="term-box">
            <h4>2. Refund Eligibility</h4>
            <ul>
              <li>
                Refunds are considered when a service is cancelled within the
                refund window (stated at purchase).
              </li>
              <li>
                Non-refundable items (such as one-time services, setup charges,
                customised integrations) are specified at checkout.
              </li>
              <li>
                Refunds may exclude transaction fees charged by payment gateways
                or banks.
              </li>
            </ul>
          </div>

          <div class="term-box">
            <h4>3. How to Request Refund</h4>
            <p>
              Submit a refund request by emailing
              <a href="mailto:doctortatkal@gmail.com">doctortatkal@gmail.com</a>
              with your order/transaction details (order ID, date, phone,
              reason). We may request verification documents.
            </p>
          </div>

          <div class="term-box">
            <h4>4. Processing Time</h4>
            <p>
              Once approved, refunds are processed within 7–14 business days
              depending on the payment provider (Razorpay/bank/card issuer).
              Actual credit time varies by bank/card issuer.
            </p>
          </div>

          <div class="term-box">
            <h4>5. Chargebacks & Disputes</h4>
            <p>
              If a chargeback/dispute is raised with your bank, the related
              account/service may be temporarily suspended during investigation.
              This may affect refund eligibility.
            </p>
          </div>

          <div class="term-box">
            <h4>6. Contact</h4>
            <p>
              For refund requests or disputes, email
              <a href="mailto:doctortatkal@gmail.com">doctortatkal@gmail.com</a>
              or call <a href="tel:+919891681188">+91 9891681188</a>.
            </p>
          </div>
        </div>
      </div>
    </section>

  <!-- Start Footer -->
  <footer class="footer">
    <div class="footer-main">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Ready to Transform Your Business?</h5>
            <button class="btn-schedule">
              Schedule Now <i class="fas fa-arrow-right"></i>
            </button>
            <div class="footer-logo mt-4">
              <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo">
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Company</h5>
            <ul class="footer-links">
              <li><a href="#">WhatsApp API Pricing</a></li>
              <li><a href="#">Whatsapp Business Solutions</a></li>
              <li><a href="#">Book a Demo</a></li>
              <li><a href="#">Contact us</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Other Locations</h5>
            <ul class="footer-links">
              <li><a href="#">New Delhi</a></li>
              <li><a href="#">Coimbatore</a></li>
              <li><a href="#">Hyderabad</a></li>
              <li><a href="#">Bangalore</a></li>
              <li><a href="#">Mumbai</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Industry</h5>
            <ul class="footer-links">
              <li><a href="#">Chatbot for Medical</a></li>
              <li><a href="#">Chatbot for Education</a></li>
              <li><a href="#">Chatbot for Automotive</a></li>
              <li><a href="#">Chatbot for Travel & Hospitality</a></li>
              <li><a href="#">Chatbot for Healthcare</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Contact us</h5>
            <div class="contact-info">
              <p>
                <i class="fas fa-map-marker-alt"></i> Address: 2ND Floor, Vinayak Complex, Sakarpur, Computer Market, Near Nirman Vihar Metro Station, Delhi-110092
              </p>
              <p><i class="fas fa-phone"></i> +91 - 9891681122</p>
              <p><i class="fas fa-envelope"></i> doctortatkal@gmail.com</p>
            </div>
            <div class="social-icons mt-3">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <p class="mb-0">
              Copyright © TatkalDoctor 2025, All rights reserved.
            </p>
          </div>
          <div class="col-md-6 text-md-end">
            <a href="{{ route('privacy') }}" class="footer-link">Privacy Policy</a> |
            <a href="{{ route('terms') }}" class="footer-link">T & C</a> |
            <a href="{{ route('refunds') }}" class="footer-link">Refunds</a> | 
             <a href="{{ route('shipping') }}" class="footer-link">Shipping & Delivery</a>
          </div>
        </div>
        <div class="text-center mt-2">
          <small>Official Partners | Business Partners</small>
        </div>
      </div>
    </div>
    <a href="https://wa.me/919891681122" class="whatsapp-float" target="_blank">
      <i class="fab fa-whatsapp"></i>
    </a>
  </footer>

  <!-- End Footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
