<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Privacy Policy — Tatkal Doctor</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="{{ asset('front') }}/assets/styles.css" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('uploads') }}/logo/tatkaldoctor-favicon.png">
  </head>
  <body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container">
        <a class="navbar-brand" href="{{ route('home') }}"
          ><img src="{{ asset('uploads') }}/logo/logo.png" alt="logo"
        /></a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav align-items-center">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('home') }}">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#products">PRODUCTS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#features">FEATURES</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#support">SUPPORT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('contact') }}">CONTACT US</a>
            </li>
            <li class="nav-item">
              <a class="nav-link demo" href="#demo">DEMO</a>
            </li>
            <li class="nav-item"><button class="btn-login">LOGIN</button></li>
          </ul>
        </div>
      </div>
    </nav>

    <section class="terms-wrapper">
      <div class="terms-container">
        <h2 class="terms-heading">Privacy Policy</h2>
        <p class="updated-date"><i>Last updated: 06 November 2025</i></p>

        <div class="terms-content">
          <div class="term-box">
            <p>
              <strong>TatkalDoctor</strong> operated by TatkalDoctor at
              <a href="https://tatkaldoctor.com">https://tatkaldoctor.com</a>.
              We act as the data fiduciary (data controller) for personal data
              we collect and process under Indian law (IT Act &amp; DPDP Act).
            </p>
          </div>

          <div class="term-box">
            <h4>1. Data We Collect</h4>
            <ul>
              <li>
                <strong>Identity &amp; Contact:</strong> name, email, phone,
                address; GSTIN/CIN if provided.
              </li>
              <li>
                <strong>Account &amp; Usage:</strong> log data, device/browser
                info, IP address, cookies.
              </li>
              <li>
                <strong>Payments:</strong> Processed via Razorpay — card/bank
                details handled by Razorpay. We receive limited transaction
                metadata only.
              </li>
              <li>
                <strong>Support Content:</strong> messages, attachments,
                feedback via email/WhatsApp/forms.
              </li>
            </ul>
          </div>

          <div class="term-box">
            <h4>2. Purposes & Legal Bases</h4>
            <p>
              We process data to provide services, improve the platform, support
              users, process payments/refunds, prevent fraud, send transactional
              messages, and (with consent) marketing. We also process data to
              comply with legal obligations.
            </p>
          </div>

          <div class="term-box">
            <h4>3. Sharing</h4>
            <p>
              We share data with hosting providers, analytics tools, customer
              support tools, payment processor Razorpay, legal authorities when
              required, and during business transfers.
            </p>
          </div>

          <div class="term-box">
            <h4>4. Cookies</h4>
            <p>
              We use cookies for essential operations, preferences, and
              analytics. Users can manage cookies through their browser
              settings; disabling some may affect site functionality.
            </p>
          </div>

          <div class="term-box">
            <h4>5. Security</h4>
            <p>
              We implement reasonable security practices, but no method is 100%
              secure. Industry-standard technical and organizational measures
              are applied.
            </p>
          </div>

          <div class="term-box">
            <h4>6. Retention</h4>
            <p>
              Personal data is retained as long as required to provide services,
              meet legal obligations, resolve disputes, and enforce agreements.
            </p>
          </div>

          <div class="term-box">
            <h4>7. Your Rights & Choices</h4>
            <p>
              You may request access, correction, update, deletion, withdraw
              consent (where applicable), and object/restrict processing —
              subject to law. Submit requests to
              <a href="mailto:doctortatkal@gmail.com">doctortatkal@gmail.com</a>
              with subject “Data Rights Request” along with basic verification
              details.
            </p>
          </div>

          <div class="term-box">
            <h4>8. Children</h4>
            <p>
              Our services are not intended for children under 14. We do not
              knowingly collect data from minors without appropriate consent.
            </p>
          </div>

          <div class="term-box">
            <h4>9. International Transfers</h4>
            <p>
              If data is processed outside India by our service providers, we
              ensure required legal safeguards are applied.
            </p>
          </div>

          <div class="term-box">
            <h4>10. Automated Decision-Making</h4>
            <p>
              We do not perform automated decision-making or profiling that has
              legal or significant effects.
            </p>
          </div>

          <div class="term-box">
            <h4>11. Grievance Officer</h4>
            <p>
              Grievance Officer: <strong>Vinay Kumar Jain</strong><br />
              Email:
              <a href="mailto:infosoft273@gmail.com">infosoft273@gmail.com</a
              ><br />
              Address: 2ND Floor, Vinayak Complex, Sakarpur, Computer Market,
              Near Nirman Vihar Metro Station, Delhi-110092<br />
              Acknowledgement target: within 2 business days • Resolution
              target: within 10 business days (max 30 days)
            </p>
          </div>

          <div class="term-box">
            <h4>12. Changes</h4>
            <p>
              We may update this Privacy Policy and post the latest version
              here. The “Last updated” date will always reflect the current
              version.
            </p>
          </div>
        </div>
      </div>
    </section>

  <!-- Start Footer -->
  <footer class="footer">
    <div class="footer-main">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Ready to Transform Your Business?</h5>
            <button class="btn-schedule">
              Schedule Now <i class="fas fa-arrow-right"></i>
            </button>
            <div class="footer-logo mt-4">
              <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo">
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Company</h5>
            <ul class="footer-links">
              <li><a href="#">WhatsApp API Pricing</a></li>
              <li><a href="#">Whatsapp Business Solutions</a></li>
              <li><a href="#">Book a Demo</a></li>
              <li><a href="#">Contact us</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Other Locations</h5>
            <ul class="footer-links">
              <li><a href="#">New Delhi</a></li>
              <li><a href="#">Coimbatore</a></li>
              <li><a href="#">Hyderabad</a></li>
              <li><a href="#">Bangalore</a></li>
              <li><a href="#">Mumbai</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Industry</h5>
            <ul class="footer-links">
              <li><a href="#">Chatbot for Medical</a></li>
              <li><a href="#">Chatbot for Education</a></li>
              <li><a href="#">Chatbot for Automotive</a></li>
              <li><a href="#">Chatbot for Travel & Hospitality</a></li>
              <li><a href="#">Chatbot for Healthcare</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Contact us</h5>
            <div class="contact-info">
              <p>
                <i class="fas fa-map-marker-alt"></i> Address: 2ND Floor, Vinayak Complex,
                Sakarpur, Computer Market,
                Near Nirman Vihar Metro Station, Delhi-110092
              </p>
              <p><i class="fas fa-phone"></i> +91 - 9891681122</p>
              <p><i class="fas fa-envelope"></i> doctortatkal@gmail.com</p>
            </div>
            <div class="social-icons mt-3">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <p class="mb-0">
              Copyright © TatkalDoctor 2025, All rights reserved.
            </p>
          </div>
          <div class="col-md-6 text-md-end">
            <a href="{{ route('privacy') }}" class="footer-link">Privacy Policy</a> |
            <a href="{{ route('terms') }}" class="footer-link">T & C</a> |
            <a href="{{ route('refunds') }}" class="footer-link">Refunds</a> | 
             <a href="{{ route('shipping') }}" class="footer-link">Shipping & Delivery</a>
          </div>
        </div>
        <div class="text-center mt-2">
          <small>Official Partners | Business Partners</small>
        </div>
      </div>
    </div>
    <a href="https://wa.me/919891681122" class="whatsapp-float" target="_blank">
      <i class="fab fa-whatsapp"></i>
    </a>
  </footer>

  <!-- End Footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
