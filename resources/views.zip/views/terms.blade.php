<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Terms &amp; Conditions — Tatkal Doctor</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <link rel="stylesheet" href="{{ asset('front') }}/assets/styles.css" />
    <link rel="icon" type="image/png" sizes="32x32" href="{{ asset('uploads') }}/logo/tatkaldoctor-favicon.png">
  </head>
  <body>
    <!-- Navbar (same as your homepage) -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top">
      <div class="container">
        <a class="navbar-brand" href="{{ route('home') }}">
          <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav align-items-center">
            <li class="nav-item">
              <a class="nav-link" href="{{ route('home') }}">HOME</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#products">PRODUCTS</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#features">FEATURES</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#support">SUPPORT</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="{{ route('contact') }}">CONTACT US</a>
            </li>
            <li class="nav-item">
              <a class="nav-link demo" href="#demo">DEMO</a>
            </li>
            <li class="nav-item"><button class="btn-login">LOGIN</button></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page header -->
    <section class="terms-wrapper">
      <div class="terms-container">
        <h2 class="terms-heading">Terms & Conditions</h2>
        <p class="updated-date"><i>Last updated: 06 November 2025</i></p>

        <div class="terms-content">
          <div class="term-box">
            <h4>1. Acceptance</h4>
            <p>
              By accessing
              <a href="https://tatkaldoctor.com">https://tatkaldoctor.com</a>
              or using our services, you agree to these Terms.
            </p>
          </div>

          <div class="term-box">
            <h4>2. Eligibility & Accounts</h4>
            <p>
              You must be competent to contract under Indian law. You are
              responsible for safeguarding your credentials.
            </p>
          </div>

          <div class="term-box">
            <h4>3. Services & Pricing</h4>
            <p>
              We may modify or discontinue any service or price at any time.
            </p>
          </div>

          <div class="term-box">
            <h4>4. Payments via Razorpay</h4>
            <p>
              Payments are securely processed by Razorpay as per their policies.
            </p>
          </div>

          <div class="term-box">
            <h4>5. Cancellations, Refunds & Returns</h4>
            <p>
              See our <a href="{{ route('refunds') }}">Cancellation & Refund Policy</a>.
            </p>
          </div>

          <div class="term-box">
            <h4>6. Acceptable Use</h4>
            <p>
              You must not use the services for unlawful or harmful activities.
            </p>
          </div>

          <div class="term-box">
            <h4>7. Intellectual Property</h4>
            <p>
              All content and IP belong to TatkalDoctor. Do not copy or
              distribute.
            </p>
          </div>

          <div class="term-box">
            <h4>8. Warranties & Disclaimers</h4>
            <p>Services are provided on an “as is” and “as available” basis.</p>
          </div>

          <div class="term-box">
            <h4>9. Limitation of Liability</h4>
            <p>
              We are not liable for indirect, incidental, or consequential
              damages.
            </p>
          </div>

          <div class="term-box">
            <h4>10. Indemnity</h4>
            <p>
              You agree to indemnify TatkalDoctor from claims arising from your
              use.
            </p>
          </div>

          <div class="term-box">
            <h4>11. Governing Law & Disputes</h4>
            <p>
              Terms governed by Indian law; courts at New Delhi have
              jurisdiction.
            </p>
          </div>

          <div class="term-box">
            <h4>12. Changes</h4>
            <p>
              Continued use after updates indicates acceptance of updated Terms.
            </p>
          </div>

          <div class="term-box">
            <h4>13. Contact</h4>
            <p>
              Email:
              <a href="mailto:doctortatkal@gmail.com">doctortatkal@gmail.com</a
              ><br />
              Phone: <a href="tel:+919891681188">+91 9891681188</a>
            </p>
          </div>
        </div>
      </div>
    </section>

  <!-- Start Footer -->
  <footer class="footer">
    <div class="footer-main">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Ready to Transform Your Business?</h5>
            <button class="btn-schedule">
              Schedule Now <i class="fas fa-arrow-right"></i>
            </button>
            <div class="footer-logo mt-4">
              <img src="{{ asset('uploads') }}/logo/logo.png" alt="logo">
            </div>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Company</h5>
            <ul class="footer-links">
              <li><a href="#">WhatsApp API Pricing</a></li>
              <li><a href="#">Whatsapp Business Solutions</a></li>
              <li><a href="#">Book a Demo</a></li>
              <li><a href="#">Contact us</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Other Locations</h5>
            <ul class="footer-links">
              <li><a href="#">New Delhi</a></li>
              <li><a href="#">Coimbatore</a></li>
              <li><a href="#">Hyderabad</a></li>
              <li><a href="#">Bangalore</a></li>
              <li><a href="#">Mumbai</a></li>
            </ul>
          </div>
          <div class="col-lg-2 col-md-6 mb-4">
            <h5 class="footer-title">Industry</h5>
            <ul class="footer-links">
              <li><a href="#">Chatbot for Medical</a></li>
              <li><a href="#">Chatbot for Education</a></li>
              <li><a href="#">Chatbot for Automotive</a></li>
              <li><a href="#">Chatbot for Travel & Hospitality</a></li>
              <li><a href="#">Chatbot for Healthcare</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-md-6 mb-4">
            <h5 class="footer-title">Contact us</h5>
            <div class="contact-info">
              <p>
                <i class="fas fa-map-marker-alt"></i> Address: 2ND Floor, Vinayak Complex, Sakarpur, Computer Market, Near Nirman Vihar Metro Station, Delhi-110092
              </p>
              <p><i class="fas fa-phone"></i> +91 - 9891681122</p>
              <p><i class="fas fa-envelope"></i> doctortatkal@gmail.com</p>
            </div>
            <div class="social-icons mt-3">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-youtube"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6">
            <p class="mb-0">
              Copyright © TatkalDoctor 2025, All rights reserved.
            </p>
          </div>
          <div class="col-md-6 text-md-end">
            <a href="{{ route('privacy') }}" class="footer-link">Privacy Policy</a> |
            <a href="{{ route('terms') }}" class="footer-link">T & C</a> |
            <a href="{{ route('refunds') }}" class="footer-link">Refunds</a> | 
             <a href="{{ route('shipping') }}" class="footer-link">Shipping & Delivery</a>
          </div>
        </div>
        <div class="text-center mt-2">
          <small>Official Partners | Business Partners</small>
        </div>
      </div>
    </div>
    <a href="https://wa.me/919891681122" class="whatsapp-float" target="_blank">
      <i class="fab fa-whatsapp"></i>
    </a>
  </footer>

  <!-- End Footer -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
