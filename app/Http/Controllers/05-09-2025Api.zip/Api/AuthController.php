<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\UserInfo;
use App\Models\Cities;
use App\Models\TrainerProfession;
use App\Models\TrainerSkills;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function register(Request $request){
        
        $validator = Validator::make($request->all(), [
            'name'     => 'required|string|max:255',
            'email'    => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $user = User::create([
            'name'     => $request->name,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return response()->json([
            'message' => 'User registered successfully',
            'user'    => $user,
        ], 201);
    }
    
    public function trainerRegister(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6|confirmed',
            'phone' => 'required|string',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'experience' => 'required|integer|min:0',
            'experience_certificate_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'city' => 'required|string|max:255',
            'skills' => 'nullable|string',
        ]);
        
    
        $profileImageName = null;
        if ($request->hasFile('profile_image')) {
            $file = $request->file('profile_image');
            $profileImageName = uniqid('profile_') . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('profile'), $profileImageName);
        }
    
        $certificateImageName = null;
        if ($request->experience > 0 && $request->hasFile('experience_certificate_image')) {
            $file = $request->file('experience_certificate_image');
            $certificateImageName = uniqid('certificate_') . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('profile'), $certificateImageName);
        }
    
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'profile_image' => $profileImageName,
            'experience' => $request->experience,
            'experience_certificate_image' => $certificateImageName,
            'city' => $request->city,
            'skills' => $request->skills,
            'profession_type' => $request->profession_type,
            'role' => 2,
        ]);
    
        $token = $user->createToken('auth_token')->plainTextToken;
    
        return response()->json([
            'message' => 'Trainer registered successfully',
            'access_token' => $token,
            'token_type' => 'Bearer',
            'user' => $user
        ], 201);
    }
    
    public function userRegister(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6|confirmed',
            'phone' => 'required|string',
            'date_of_birth' => 'required|string',
            'gender' => 'required|string',
            'profile_image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'height' => 'nullable|string',
            'weight' => 'nullable|string',
            'goals' => 'nullable|string',
            'target_weight' => 'nullable|string',
            'target_date' => 'nullable|string',
            'exercise_level' => 'nullable|string',
            'diet_preference' => 'nullable|string',
            'daily_water_intake' => 'nullable|string',
            'sleep_hours' => 'nullable|string',
            'supplements_taken' => 'nullable|string',
            'food_allergies' => 'nullable|string',
        ]);
        
    
        $profileImageName = null;
        if ($request->hasFile('profile_image')) {
            $file = $request->file('profile_image');
            $profileImageName = uniqid('profile_') . '.' . $file->getClientOriginalExtension();
            $file->move(public_path('profile'), $profileImageName);
        }
    
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'profile_image' => $profileImageName,
            'role' => 3,
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
        ]);
        $user_info = UserInfo::create([
            'user_id' => $user->id,
            'height' => $request->height,
            'weight' => $request->weight,
            'goals' => $request->goals,
            'target_weight' => $request->target_weight,
            'target_date' => $request->target_date,
            'exercise_level' => $request->exercise_level,
            'diet_preference' => $request->diet_preference,
            'daily_water_intake' => $request->daily_water_intake,
            'sleep_hours' => $request->sleep_hours,
            'supplements_taken' => $request->supplements_taken,
            'food_allergies' => $request->food_allergies,
        ]);
    
        $token = $user->createToken('auth_token')->plainTextToken;
        $get_user = User::where('id', $user->id)->with('user_info')->first();
        return response()->json([
            'message' => 'User registered successfully',
            'access_token' => $token,
            'token_type' => 'Bearer',
            'user' => $get_user
        ], 201);
    }


    public function login(Request $request){
        $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        $user = User::where('email', $request->email)->first();
        if (! $user || ! Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
        
        $token = $user->createToken('auth_token')->plainTextToken;
        return response()->json([
            'message' => 'Login successful',
            'access_token' => $token,
            'token_type' => 'Bearer',
            'user' => $user
        ]);
    }

    public function logout(Request $request){
        
        $request->user()->currentAccessToken()->delete();
        return response()->json([
            'message' => 'Logged out successfully'
        ]);
    }
    
    public function AllCities(Request $request){
        
        $cities = Cities::where('status', 1)->get();
        return response()->json(['status' => 1, 'all_cities' => $cities], 200);
        
    }
    
    public function TrainerType(Request $request){
        
        $trainer_type = TrainerProfession::where('status', 1)->with('trainer_skills')->get();
        return response()->json(['status' => 1, 'trainer_type' => $trainer_type], 200);
        
    }

}

