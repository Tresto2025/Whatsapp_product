<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ChatSessions;
use App\Models\Appointments;
use App\Models\Cities;
use App\Models\User;
use Twilio\Rest\Client;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;
use Illuminate\Support\Str;

class WhatsAppController extends Controller
{
    public function webhook(Request $request)
    {
        Log::info('📥 WhatsApp Webhook Hit', $request->all());

        $from = $request->input('From');
        $body = trim($request->input('Body'));
        $lowerBody = strtolower($body);
        $phone = str_replace('whatsapp:', '', $from);

        $session = ChatSessions::firstOrCreate(['phone' => $phone]);
        $data = $session->data ? json_decode($session->data, true) : [];
        
        if (!empty($session->completed)) {
            return $this->sendMessage($from, "❌ Your previous session has ended. Please scan your doctor’s QR code to start a new booking.");
        }

        // ✅ Global reschedule trigger
        if ($body === 'reschedule_booking' || $lowerBody === 'reschedule' || $lowerBody === 'reschedule appointment') {

            $session->mode = 'rescheduling';
            $session->step = 'awaiting_reschedule_selection';
            $session->save();

            $appointments = Appointments::where('phone', $phone)
                ->where('status', 1)
                ->whereDate('date', '>=', now())
                ->with('doctor_detail')
                ->orderBy('date', 'asc')
                ->orderBy('start_time', 'asc')
                ->get();

            if ($appointments->isEmpty()) {
                return $this->sendMessage($from, "❌ You have no upcoming confirmed appointments.");
            }

            $list = "🔄 You have the following bookings:\n\n";
            foreach ($appointments as $index => $appt) {
                $patientName = $appt->name ?? 'N/A';
                $doctorProfession = $appt->profession_type ?? 'N/A';
                $doctorFirstName = $appt->doctor_detail->first_name ?? '';
                $doctorLastName  = $appt->doctor_detail->last_name ?? '';
                $doctorName      = trim($doctorFirstName . ' ' . $doctorLastName) ?: 'N/A';
                $service = $appt->service_type ?? 'N/A';
                $purpose = $appt->purpose ?? 'N/A';
                $date = Carbon::parse($appt->date)->format('D, d M Y');
                $time = $appt->time ?? 'N/A';
                $address = $appt->doctor_detail->address ?? 'N/A';

                $num = $index + 1;
                $list .= "{$num}. Patient: {$patientName}\n";
                $list .= "Doctor: {$doctorName} ({$doctorProfession})\n";
                $list .= "Service: {$service}\n";
                $list .= "Purpose: {$purpose}\n";
                $list .= "Date: {$date}\n";
                $list .= "Time: {$time}\n";
                $list .= "Address: {$address}\n\n";
            }
            $list .= "👉 Please reply with the number of the appointment you want to reschedule.";

            $session->data = json_encode(['appointments' => $appointments->pluck('id')->toArray()]);
            $session->save();

            return $this->sendMessage($from, $list);
        }

        // doctor QR flow
        if (preg_match('/doctor code wab-(\d+)/i', $body, $matches)) {
            $doctorId = $matches[1];
            $data['doctor_id'] = $doctorId;
            $session->data = json_encode($data);
            $session->step = 'awaiting_choice';
            $session->mode = 'menu';
            $session->completed = 0;
            $session->save();
    
            return $this->sendListPickerTemplate($from);
        }
        
        if (!$session->step) {
            return $this->sendMessage($from, "❌ Please scan your doctor’s QR code to start the chat.");
        }

        // Menu choice handling
        if ($session->step === 'awaiting_choice') {
            if ($body === 'new_booking') {
                $doctor = User::find($data['doctor_id']);
                
                if ($doctor && $doctor->booking_enabled == 0) {
                    return $this->sendMessage($from, "Sorry, bookings are closed for today. Please try again tomorrow.");
                }
    
                $startDate = Carbon::now()->startOfDay();
                $endDate = Carbon::now()->addDays(6)->endOfDay();
        
                $appointmentCount = Appointments::where('phone', $phone)->where('status', 1)->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])->count();
        
                if ($appointmentCount >= 3) {
                    return $this->sendMessage($from, "Sorry, you have already reached the maximum of 3 appointments for this week. You cannot book a new appointment right now.");
                }
                $session->mode = 'booking';
                $session->step = 'awaiting_name';
                $session->save();
        
                return $this->sendAskNameTemplate($from);
            } elseif ($body === 'reschedule_booking') {
                // handled above by global trigger
            } else {
                return $this->sendMessage($from, "❌ Please scan your doctor’s QR code to start the chat.");
            }
        }

        // Booking flow
        if ($session->mode === 'booking') {
            switch ($session->step) {
        
                case 'awaiting_name':
                    $data['name'] = $body;
                    $session->data = json_encode($data);
                    $session->step = 'awaiting_service_type';
                    $session->save();
                    return $this->sendServiceTypeTemplate($from);
        
                case 'awaiting_service_type':
                    $title = $request->input('interactive.list_reply.title');
                    $id    = $request->input('interactive.list_reply.id');
                    $selectedService = $title ?: $id ?: $body; 
                    $data['service_type'] = $selectedService;
                
                    $session->data = json_encode($data);
                    $session->step = 'awaiting_date';
                    $session->save();
                    return $this->sendDateListNew($from);
        
                case 'awaiting_date':
                    $selectedDate = $request->input('interactive.list_reply.id') 
                        ?? $request->input('interactive.list_reply.title') 
                        ?? $body;
        
                    if (is_numeric($selectedDate)) {
                        $index = (int)$selectedDate - 1;
                        if ($index >= 0 && $index < 7) {
                            $selectedDate = Carbon::now()->addDays($index)->format('Y-m-d');
                        }
                    }
        
                    $data['date'] = $selectedDate;
                    $session->data = json_encode($data);
                    $session->step = 'awaiting_time';
                    $session->save();
                    return $this->sendTimeTemplate($from);
        
                case 'awaiting_time':
                    $data = json_decode($session->data ?? '{}', true);
                    $selectedTime = $request->input('interactive.list_reply.title') 
                                 ?? $request->input('interactive.list_reply.id') 
                                 ?? $body;
                
                    Log::info('Time selection payload', [
                        'body' => $body,
                        'selectedTime' => $selectedTime,
                        'sessionData' => $data
                    ]);
                
                    $tz = 'Asia/Kolkata';
                    $now = Carbon::now($tz);
                
                    $selectedDate = $data['date'] ?? $now->format('Y-m-d');
                    $isToday = Carbon::parse($selectedDate, $tz)->isSameDay($now);
                    $times = explode('-', $selectedTime);
                    if(count($times) < 2){
                        $this->sendMessage($from, "❌ Invalid time slot format. Please select a valid slot.");
                        return $this->sendTimeTemplate($from);
                    }
                
                    $startTimeStr = trim($times[0]);
                    $endTimeStr   = trim($times[1]);
                
                    if (!str_contains($startTimeStr, 'AM') && !str_contains($startTimeStr, 'PM')) {
                        if (str_contains($endTimeStr, 'AM') || str_contains($endTimeStr, 'PM')) {
                            $startTimeStr .= ' ' . substr($endTimeStr, -2);
                        }
                    }
                    try {
                        $slotEndDateTime = Carbon::createFromFormat('Y-m-d h:i A', $selectedDate.' '.$endTimeStr, $tz);
                    } catch (\Exception $e) {
                        $this->sendMessage($from, "❌ Invalid time format. Please select a valid slot.");
                        return $this->sendTimeTemplate($from);
                    }
                    if ($isToday && $slotEndDateTime->lessThanOrEqualTo($now)) {
                        $this->sendMessage($from, "❌ You have selected a past time. Please select a future time.");
                        return $this->sendTimeTemplate($from);
                    }
                    $data['time'] = $selectedTime;
                    $session->data = json_encode($data);
                    $session->step = 'awaiting_purpose';
                    $session->save();
                
                    return $this->sendPurposeTemplate($from);
        
                case 'awaiting_purpose':
                    $data['purpose'] = $body;
                    $rawTime = $data['time'];
                    $startTimeString = trim(explode('-', $rawTime)[1] ?? $rawTime);
                    $startTime = Carbon::parse($startTimeString)->format('H:i:s');
                    $patient_name = $data['name'];
                
                    $appointment = Appointments::create([
                        'phone'        => $phone,
                        'name'         => $data['name'],
                        'service_type' => $data['service_type'] ?? null,
                        'date'         => $data['date'],
                        'time'         => $data['time'],
                        'purpose'      => $data['purpose'],
                        'doctor_id'    => $data['doctor_id'] ?? null,
                        'start_time'   => $startTime,
                    ]);
                
                    $session->delete();
                
                    $get_doctor = User::where('id', $data['doctor_id'])->first();
                    $doctorFirstName  = $get_doctor->first_name ?? '';
                    $doctorLastName   = $get_doctor->last_name ?? '';
                    $doctorName       = trim($doctorFirstName . ' ' . $doctorLastName) ?: 'N/A';
                    $doctorProfession = $get_doctor->profession_type ?? 'N/A';
                    $address          = $get_doctor->address;
                    $formattedDate    = Carbon::parse($appointment->date)->format('D, d M Y');
                
                    // ✅ Combine reschedule CTA inside main message
                    $bizDigits = preg_replace('/\D+/', '', config('services.twilio.whatsapp_from'));
                    $rescheduleLink = "https://wa.me/{$bizDigits}?text=reschedule_booking";
                
                    $msg = "Thanks {$patient_name} for your booking service with us.\n".
                           "*Here are your appointment details!*\n\n".
                           "*Doctor* : {$doctorName} ({$doctorProfession})\n".
                           "*Service* : {$appointment->service_type}\n".
                           "*Purpose* : {$appointment->purpose}\n".
                           "*Date* : {$formattedDate}\n".
                           "*Time* : {$appointment->time}\n\n".
                           "*Address* : {$address}\n\n".
                           "If you need to make changes later, reply with *RESCHEDULE* anytime.\n" .
                           "Or tap here: {$rescheduleLink}";
                
                    $this->sendMessage($from, $msg);
                
                    // ✅ Send Reschedule Button template (remains optional)
                    try {
                        $twilio = new Client(config('services.twilio.sid'), config('services.twilio.token'));
                        $response = $twilio->messages->create($from, [
                            'from' => config('services.twilio.whatsapp_from'),
                            'contentSid' => 'HXe8a98c6233096de9b35c01f753fe618f',
                            'contentVariables' => json_encode(new \stdClass()),
                        ]);
                        \Log::info("✅ Reschedule button template sent", ['sid' => $response->sid]);
                    } catch (\Exception $e) {
                        \Log::error("❌ Error sending reschedule button template", [
                            'error' => $e->getMessage(),
                            'trace' => $e->getTraceAsString()
                        ]);
                    }
                
                    return;

            }
        }

        // Rescheduling flow continues unchanged...
        if ($session->mode === 'rescheduling') {
            switch ($session->step) {
        
                // Step 1: Patient chooses which appointment
                case 'awaiting_reschedule_selection':
                    
                    $data = $session->data ? json_decode($session->data, true) : [];
                    $appointments = $data['appointments'] ?? [];

                    $choiceStr = preg_replace('/\D+/', '', trim((string)$body));
                    $choice = $choiceStr === '' ? 0 : intval($choiceStr);

                    if ($choice < 1 || $choice > count($appointments)) {
                        return $this->sendMessage($from, "❌ Invalid choice. Please reply with a valid number from the list.");
                    }

                    $selectedAppointmentId = $appointments[$choice - 1];
                    $data['appointment_id'] = $selectedAppointmentId;

                    $session->data = json_encode($data);
                    $session->step = 'awaiting_new_date';
                    $session->save();

                    return $this->sendDateListNew($from);

                // Step 2: Pick new date
                case 'awaiting_new_date':
                    
                    $data = $session->data ? json_decode($session->data, true) : [];

                    $selectedDate = $request->input('interactive.list_reply.id') 
                                    ?? $request->input('interactive.list_reply.title') 
                                    ?? $body;

                    $data['new_date'] = $selectedDate;

                    $session->data = json_encode($data);
                    $session->step = 'awaiting_new_time';
                    $session->save();

                    return $this->sendTimeTemplate($from);

                // Step 3: Pick new time
                case 'awaiting_new_time':
                    $data = $session->data ? json_decode($session->data, true) : [];

                    $title = $request->input('interactive.list_reply.title');
                    $id = $request->input('interactive.list_reply.id');
                    $selectedTime = $title ?: $id ?: $body;
                
                    $data['new_time'] = $selectedTime;
                
                    $tz = 'Asia/Kolkata';
                    $now = Carbon::now($tz);
                
                    $selectedDate = $data['new_date'] ?? $now->format('Y-m-d');
                    $isToday = Carbon::parse($selectedDate, $tz)->isSameDay($now);
                
                    // Extract start and end times from slot
                    $times = explode('-', $selectedTime);
                    if(count($times) < 2){
                        $this->sendMessage($from, "❌ Invalid time slot format. Please select a valid slot.");
                        return $this->sendTimeTemplate($from);
                    }
                
                    $startTimeStr = trim($times[0]);
                    $endTimeStr   = trim($times[1]);
                
                    // Append AM/PM to startTime if missing
                    if (!str_contains($startTimeStr, 'AM') && !str_contains($startTimeStr, 'PM')) {
                        if (str_contains($endTimeStr, 'AM') || str_contains($endTimeStr, 'PM')) {
                            $startTimeStr .= ' ' . substr($endTimeStr, -2);
                        }
                    }
                
                    // Parse end time for validation
                    try {
                        $slotEndDateTime = Carbon::createFromFormat('Y-m-d h:i A', $selectedDate.' '.$endTimeStr, $tz);
                    } catch (\Exception $e) {
                        $this->sendMessage($from, "❌ Invalid time format. Please select a valid slot.");
                        return $this->sendTimeTemplate($from);
                    }
                
                    // Reject if the slot end time is in the past for today
                    if ($isToday && $slotEndDateTime->lessThanOrEqualTo($now)) {
                        $this->sendMessage($from, "❌ You have selected a past time. Please select a future time.");
                        return $this->sendTimeTemplate($from); // resend template
                    }
                
                    // Parse start time for storing in DB
                    $startTime = Carbon::parse($startTimeStr)->format('H:i:s');
                
                    // Update appointment
                    $appointment = Appointments::find($data['appointment_id']);
                    if ($appointment) {
                        $appointment->update([
                            'date'       => $selectedDate,
                            'time'       => $selectedTime,
                            'start_time' => $startTime,
                        ]);
                
                        $session->delete();
                
                        $formattedDate = Carbon::parse($selectedDate)->format('D, d M Y');
                        $get_doctor = User::find($appointment->doctor_id);
                        
                        $doctorFirstName = $get_doctor->first_name ?? '';
                        $doctorLastName  = $get_doctor->last_name ?? '';
                        $doctorName      = trim($doctorFirstName . ' ' . $doctorLastName);
                        $doctorProfession = $get_doctor->profession_type ?? 'N/A';
                        if (empty($doctorName)) {
                            $doctorName = 'N/A';
                        }
                        $address = $get_doctor->address ?? '';
                
                        return $this->sendMessage($from, "✅ Your appointment has been *rescheduled*:\n\n".
                            "*Doctor* : {$doctorName} ({$doctorProfession})\n".
                            "*Service*: {$appointment->service_type}\n".
                            "*Purpose* : {$appointment->purpose}\n".
                            "*Date* : {$formattedDate}\n".
                            "*Time* : {$selectedTime}\n\n".
                            "*Address*: {$address}"
                        );
                    } else {
                        $session->delete();
                        return $this->sendMessage($from, "❌ Appointment not found. Please type *hi* to try again.");
                    }

                default:
                    return $this->sendMessage($from, "❌ Invalid step. Please type *hi* to start again.");
            }
        }

        return $this->sendMessage($from, "❌ Please scan your doctor’s QR code to start the chat.");
    }

    // --- helper methods remain exactly as you had them ---
    protected function sendListPickerTemplate($to){
        $twilio = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );

        $twilio->messages->create($to, [
            'from' => config('services.twilio.whatsapp_from'),
            'contentSid' => 'HXe464ca68182fdb9cf70bfd35fcd757f5',
            //'contentSid' => 'HX6ce0f8d6c324a5d5bd99f6abd3977990', // menu_item1 new : HX68c3caf4dfaf5807a525dc852082abdd
        ]);

        return response('List menu sent', 200);
    }

    // Sends name asking template
    protected function sendAskNameTemplate($to){
        $twilio = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );

        $twilio->messages->create($to, [
            'from' => config('services.twilio.whatsapp_from'),
            'contentSid' => 'HX491c3cbb0907b4c300261a490299c9de',
            //'contentSid' => 'HX3d495a5593f8edf7b97607b97d0d37dc', // ask_for_name new : HX491c3cbb0907b4c300261a490299c9de
        ]);

        return response('Ask name template sent', 200);
    }

    // Sends static time slot list template
    protected function sendTimeTemplate($to){
        $twilio = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );

        $twilio->messages->create($to, [
            'from' => config('services.twilio.whatsapp_from'),
            'contentSid' => 'HX6f6ff36368a72a244a0f37b930bae694',
            //'contentSid' => 'HX1a741e3e8350451ebc060a087ca98c2b', // time slot template new : HX0ce927e72d9700a42d3cd55ddfd020f1
        ]);

        return response('Time template sent', 200);
    }
    
    // Sends city list dynamically
    protected function sendCityList($to){
        $cities = Cities::where('status', 1)->pluck('city_name')->toArray();
        if (empty($cities)) {
            return $this->sendMessage($to, "⚠️ No cities available at the moment.");
        }
        $text = "🏙️ Please reply with your city name from the following list:\n\n";
        foreach ($cities as $index => $city) {
            $text .= ($index + 1) . ". " . $city . "\n";
        }
        return $this->sendMessage($to, $text);
    }

    // Sends simple message
    protected function sendMessage($to, $message){
        $twilio = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );

        $twilio->messages->create($to, [
            'from' => config('services.twilio.whatsapp_from'),
            'body' => $message
        ]);

        return response('OK', 200);
    }

    // Optional stubs
    protected function sendDateList($to){
        return $this->sendMessage($to, "📅 Please reply with your new appointment date (YYYY-MM-DD).");
    }

    protected function sendTimeList($to){
        return $this->sendMessage($to, "⏰ Please reply with your new time slot.");
    }
    
protected function sendDateListNew($to)
{
    $twilio = new Client(
        config('services.twilio.sid'),
        config('services.twilio.token')
    );

    $tz = 'Asia/Kolkata';
    $now = Carbon::now($tz);

    // Cutoff time 16:00
    $cutoffTime = Carbon::createFromFormat('H:i:s', '16:00:00', $tz);

    $datesRaw = [];
    $datesPretty = [];

    $daysAdded = 0;
    $i = 0;

    while ($daysAdded < 7) {
        $d = $now->copy()->addDays($i);

        // Today cutoff check
        if ($i === 0 && $now->greaterThanOrEqualTo($cutoffTime)) {
            $i++;
            continue; // skip today
        }

        $datesRaw[] = $d->format('Y-m-d');
        $datesPretty[] = $d->format('D, d M Y');

        $daysAdded++;
        $i++;
    }

    // Prepare template variables
    $vars = [];
    for ($i = 0; $i < 7; $i++) {
        $vars["DateId" . ($i + 1)] = $datesRaw[$i] ?? 'NA';
        $vars["Date" . ($i + 1)] = $datesPretty[$i] ?? 'NA';
    }

    $twilio->messages->create($to, [
        'from' => config('services.twilio.whatsapp_from'),
        'contentSid' => 'HX8c8e03fa36b0019278327cdc0786da30',
        'contentVariables' => json_encode($vars),
    ]);

    return response('Dynamic date list sent', 200);
}

    
    // Send service type template
    protected function sendServiceTypeTemplate($to){
        $twilio = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );
    
        $twilio->messages->create($to, [
            'from' => config('services.twilio.whatsapp_from'),
            'contentSid' => 'HX32adec5b7e72ee686b10452b21e6edbb'
        ]);
        return response('Service type list sent', 200);
    }
    
    // Send purpose of consultation template
    protected function sendPurposeTemplate($to){
        $twilio = new Client(
            config('services.twilio.sid'),
            config('services.twilio.token')
        );
    
        $twilio->messages->create($to, [
            'from' => config('services.twilio.whatsapp_from'),
            'contentSid' => 'HX5b430d3cda9fbf6ce0a7965c48d49d87'
        ]);
        return response('Purpose template sent', 200);
    }

}
